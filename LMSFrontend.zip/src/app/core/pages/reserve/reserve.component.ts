import { Component, Input, EventEmitter, Output, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { LoanDataService } from '../../services/data/loan.data.service';
import { BookReadDto, BookRelationDto } from '../../models/dtos/book.dtos';
import { ActivatedRoute } from '@angular/router';
import { BookDataService } from '../../services/data/book.data.service';

@Component({
  selector: 'reserve',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './reserve.component.html',
  styleUrl: './reserve.component.scss'
})
export class ReserveComponent implements OnInit {
  loanService = inject(LoanDataService);
  bookService = inject(BookDataService);
  route = inject(ActivatedRoute);
  @Output() closed = new EventEmitter<void>();
  
  book!: BookReadDto;
  pickupDate: string = '';

  async ngOnInit() {
    this.book = history.state.book;
    
    if (!this.book) {
      const isbn: number = Number(this.route.snapshot.paramMap.get('isbn')!);
      this.bookService.getItemById(isbn).subscribe({
        next: (book) => {
          this.book = book;
        }
      });
    }
  }

  confirmReservation() {
    if (!this.pickupDate) {
      alert('Te rugăm să selectezi o dată de ridicare!');
      return;
    }

    var reservationList: BookRelationDto[];

    reservationList = localStorage.getItem("reservationList") !== null
                ? JSON.parse(localStorage.getItem("reservationList")!) : [];
    reservationList.push({isbn: this.book.isbn, count: 1});
    localStorage.setItem("reservationList", JSON.stringify(reservationList));

    const currentUserId = 1; // De preluat din Auth Service în viitor

    // this.loanService.reserve(dto, currentUserId, this.pickupDate).subscribe({
    //   next: () => {
    //     alert('Rezervare confirmată cu succes!');
    //     this.close();
    //   },
    //   error: (err: any) => {
    //     const msg = err.error?.message || err.message || 'Eroare la server';
    //     alert('Eroare: ' + msg);
    //   }
    // });
  }

  close() {
    this.closed.emit();
  }
}